# lab_1

A Pen created on CodePen.

Original URL: [https://codepen.io/Hoychuk/pen/OPJpYOW](https://codepen.io/Hoychuk/pen/OPJpYOW).

